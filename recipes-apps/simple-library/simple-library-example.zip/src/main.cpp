#include <iostream>

#include "file_creator.hpp"

int main()
{
    std::cout << "Hello world" << std::endl;
}